const premium=[
["Alight Motion","https://cdn.simpleicons.org/alightmotion"],["CapCut","https://cdn.simpleicons.org/capcut"],["Netflix","https://cdn.simpleicons.org/netflix"],["Canva Pro","https://cdn.simpleicons.org/canva"],["Bstation","https://cdn.simpleicons.org/bilibili"],["IqiYI","https://cdn.simpleicons.org/iqiyi"],["LOKLOK","https://cdn.simpleicons.org/loklok"],["Nord VPN","https://cdn.simpleicons.org/nordvpn"],["Picsart","https://cdn.simpleicons.org/picsart"],["Remini Pro","https://cdn.simpleicons.org/remini"],["Scribd","https://cdn.simpleicons.org/scribd"],["Spotify Premium","https://cdn.simpleicons.org/spotify"],["Surfshark VPN","https://cdn.simpleicons.org/surfshark"],["YouTube Premium","https://cdn.simpleicons.org/youtube"]
];
const games=[
["Mobile Legends","https://cdn.simpleicons.org/mobilelegends"],["Free Fire","https://cdn.simpleicons.org/freefire"],["PUBG Mobile","https://cdn.simpleicons.org/pubg"],["Roblox","https://cdn.simpleicons.org/roblox"],["Valorant","https://cdn.simpleicons.org/valorant"],["Genshin Impact","https://cdn.simpleicons.org/genshinimpact"]
];
// Produk Jasa & Panel yang ditampilkan pada video referensi pengguna.
const services=[
["Panel Pterodactyl","Rp15.000","🖥️"],["VPS Digital Ocean","Rp55.000","🗄️"],["Install Panel","Rp25.000","⚙️"],
["Jasa Install VPS","Rp25.000","🛠️"],["Sewa Bot","Rp25.000","🤖"],["Nokos WhatsApp","Rp25.000","https://cdn.simpleicons.org/whatsapp"],
["Nokos Telegram","Rp25.000","https://cdn.simpleicons.org/telegram"],["Pembuatan Website","Rp65.000","🌐"],["Partner Store","Rp45.000","🏪"],
["Partner Panel","Rp25.000","☁️"],["Script Bot Group","Rp25.000","💻"],["Rename Script","Rp25.000","📄"],
["Script Bot Bug","Rp25.000","🐞"],["Unbanned WhatsApp","Rp25.000","https://cdn.simpleicons.org/whatsapp"],["Banned WhatsApp","Rp25.000","🚫"],
["Bug WhatsApp","Rp25.000","⚠️"],["Murid Banned","Rp25.000","👥"],["Murid Unbanned","Rp25.000","👥"],
["JPM Otomatis","Rp25.000","⚡"],["Murid Store","Rp25.000","🛒"],["Apk Bug Rdvsp","Rp50.000","📱"]
];
// Gambar produk lokal: cukup ganti file di assets/products/ untuk memperbarui gambar.
const productImages={
  "IqiYI":"assets/products/iqiyi.png",
  "Picsart":"assets/products/picsart.png",
  "LOKLOK":"assets/products/loklok.png",
  "Bstation":"assets/products/bstation.png",
  "Scribd":"assets/products/scribd.png",
  "CapCut":"assets/products/capcut.png",
  "Remini Pro":"assets/products/remini.png",
  "Surfshark VPN":"assets/products/surfsharkvpn.png",
  "Alight Motion":"assets/products/alight-motion.jpeg",
  "Canva Pro":"assets/products/canva-pro.jpg",
  "Pembuatan Website":"assets/products/pembuatan-website.png",
  "Panel Pterodactyl":"assets/products/panel-pterodactyl.png",
  "VPS Digital Ocean":"assets/products/vps-digital-ocean.png",
  "Install Panel":"assets/products/install-panel.png",
  "Nokos WhatsApp":"assets/products/nokos-whatsapp.png",
  "Script Bot Group":"assets/products/script-bot-group.png",
  "Rename Script":"assets/products/rename-script.png",
  "Unbanned WhatsApp":"assets/products/unbanned-whatsapp.png",
  "Bug WhatsApp":"assets/products/bug-whatsapp.png",
  "JPM Otomatis":"assets/products/jpm-otomatis.png",
  "Sewa Bot":"assets/products/sewa-bot.png",
  "Partner Store":"assets/products/partner-store.png",
  "Partner Panel":"assets/products/partner-panel.png",
  "Script Bot Bug":"assets/products/script-bot-bug.png",
  "Banned WhatsApp":"assets/products/banned-whatsapp.png",
  "Murid Banned":"assets/products/murid-banned.png",
  "Murid Unbanned":"assets/products/murid-unbanned.png",
  "Murid Store":"assets/products/murid-store.png",
  "Apk Bug Rdvsp":"assets/products/apk-bug-rdvsp.png",
  "PUBG Mobile":"assets/products/pubgmobile.png",
  "Free Fire":"assets/products/freefire.png",
  "Mobile Legends":"assets/products/mobilelegends.png",
  "Valorant":"assets/products/valorant.png",
  "Roblox":"assets/products/roblox.png",
  "Genshin Impact":"assets/products/genshinimpact.png"
};
const grad=["linear-gradient(135deg,#eaf2ff,#fff)","linear-gradient(135deg,#f5f7fa,#fff)","linear-gradient(135deg,#edf9f4,#fff)","linear-gradient(135deg,#eef6ff,#fff)","linear-gradient(135deg,#f8f0ff,#fff)","linear-gradient(135deg,#fff4e8,#fff)"];
const WA_NUMBER="6283871936492";
function waProduct(name){const text=`Halo Lotuscrop Store, saya ingin memesan produk: ${name}. Mohon info harga dan proses pesanannya.`;return `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(text)}`;}
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function card(x,i,kind="normal"){
 const name=x[0], img=productImages[name]||(kind==="service"?x[2]:x[1]), price=kind==="service"?x[1]:"Mulai Rp5.000";
 const isImg=typeof img==="string"&&(/^(https?:|assets\/|data:image)/.test(img)||/\.(png|jpe?g|webp|gif|svg)(\?.*)?$/i.test(img));
 const visual=isImg?`<img src="${esc(img)}" alt="${esc(name)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'">`:`<span class="product-emoji">${esc(img)}</span>`;
 return `<article class="product" data-product="${esc(name)}" tabindex="0" role="button" aria-label="Pesan ${esc(name)} melalui WhatsApp"><div class="product-media" style="background:${grad[i%grad.length]}">${visual}<span class="product-fallback">${esc(name.slice(0,2).toUpperCase())}</span></div><div class="product-body"><h3>${esc(name)}</h3><p>${esc(price)}</p></div></article>`;
}
let featuredTimer=null,featuredCleanup=null;
function render(type="premium"){
 const data=type==="premium"?premium:type==="game"?games:services;
 const kind=type==="service"?"service":"normal";
 if(featuredTimer)clearInterval(featuredTimer); if(featuredCleanup)featuredCleanup();
 const featuredEl=document.getElementById("featured");
 const featuredItems=data.slice(0,Math.min(9,data.length));
 const clones=featuredItems.slice(0,3);
 featuredEl.innerHTML=featuredItems.concat(clones).map((x,i)=>card(x,i,kind)).join("");
 featuredEl.style.transition="none";featuredEl.style.transform="translateX(0)";
 requestAnimationFrame(initFeaturedSlider);
 document.getElementById("catalog").innerHTML=data.map((x,i)=>card(x,i,kind)).join("");
 document.getElementById("catalogTitle").textContent=type==="premium"?"📦 Top Up Aplikasi Premium":type==="game"?"🎮 Top Up Game":"🛠️ Jasa & Panel";
 document.getElementById("catalogEyebrow").textContent=type==="service"?"PRODUK SESUAI VIDEO REFERENSI":"KATALOG DIGITAL";
}
function initFeaturedSlider(){
 const viewport=document.getElementById("featuredViewport"),track=document.getElementById("featured"); if(!viewport||!track)return;
 const items=Array.from(track.querySelectorAll(".product")); if(items.length<2)return;
 const originalCount=items.length-3; let index=0;
 const step=()=>items[0].getBoundingClientRect().width+(parseFloat(getComputedStyle(track).gap)||18);
 const move=()=>{index++;track.style.transition="transform .65s cubic-bezier(.22,.61,.36,1)";track.style.transform=`translateX(-${index*step()}px)`;};
 const reset=()=>{if(index>=originalCount){index=0;track.style.transition="none";track.style.transform="translateX(0)";requestAnimationFrame(()=>requestAnimationFrame(()=>track.style.transition="transform .65s cubic-bezier(.22,.61,.36,1)"));}};
 track.addEventListener("transitionend",reset);
 const reduced=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;
 const stop=()=>{if(featuredTimer)clearInterval(featuredTimer)};
 const start=()=>{if(reduced)return;stop();featuredTimer=setInterval(move,3000)};
 if(!reduced){start();viewport.addEventListener("mouseenter",stop);viewport.addEventListener("mouseleave",start);}
 featuredCleanup=()=>{stop();viewport.removeEventListener("mouseenter",stop);viewport.removeEventListener("mouseleave",start);track.removeEventListener("transitionend",reset)};
}
document.querySelectorAll(".category").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".category").forEach(b=>b.classList.remove("active"));btn.classList.add("active");render(btn.dataset.type)}));
document.getElementById("menuBtn").addEventListener("click",()=>{const m=document.getElementById("mobileMenu");m.style.display=m.style.display==="block"?"none":"block"});
document.getElementById("searchBtn").addEventListener("click",()=>{const s=document.getElementById("searchBox");s.style.display=s.style.display==="block"?"none":"block";if(s.style.display==="block")document.getElementById("searchInput").focus()});
document.getElementById("searchInput").addEventListener("input",e=>{const q=e.target.value.toLowerCase();document.querySelectorAll("#catalog .product").forEach(p=>p.style.display=p.innerText.toLowerCase().includes(q)?"":"none")});
function openProductWhatsApp(el){const name=el?.dataset?.product||"produk pilihan";window.open(waProduct(name),"_blank","noopener,noreferrer");}
function bindProductClicks(){["featured","catalog"].forEach(id=>{const root=document.getElementById(id);if(!root)return;root.addEventListener("click",e=>{const product=e.target.closest(".product");if(product)openProductWhatsApp(product)});root.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){const product=e.target.closest(".product");if(product){e.preventDefault();openProductWhatsApp(product)}}});});}
bindProductClicks();render();
(function initHeroSlider(){const track=document.getElementById('heroTrack'),dots=document.getElementById('heroDots');if(!track||!dots)return;const slides=Array.from(track.querySelectorAll('.hero-slide'));let index=0,timer=null;const reduced=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;slides.forEach((_,i)=>{const b=document.createElement('button');b.type='button';b.className='hero-dot'+(i===0?' active':'');b.setAttribute('aria-label','Tampilkan banner '+(i+1));b.addEventListener('click',()=>go(i,true));dots.appendChild(b)});const dotEls=Array.from(dots.children);function go(next,manual=false){index=(next+slides.length)%slides.length;track.style.transform=`translateX(-${index*100}%)`;dotEls.forEach((d,i)=>d.classList.toggle('active',i===index));if(manual)restart()}function restart(){if(reduced)return;clearInterval(timer);timer=setInterval(()=>go(index+1),4500)}restart();track.addEventListener('mouseenter',()=>{if(!reduced)clearInterval(timer)});track.addEventListener('mouseleave',restart)})();
